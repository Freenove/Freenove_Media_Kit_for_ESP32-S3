# Platforms

```eval_rst

.. toctree::
   :maxdepth: 2

   pc-simulator
   nxp
   stm32
   espressif
   renesas
   arduino
   tasmota-berry
   cmake
```

