#include <Fonts/Font32rle.c>

#define nr_chrs_f32 96
#define chr_hgt_f32 26
#define baseline_f32 19
#define data_size_f32 8
#define firstchr_f32 32

extern const unsigned char widtbl_f32[96];
extern const unsigned char* const chrtbl_f32[96];
